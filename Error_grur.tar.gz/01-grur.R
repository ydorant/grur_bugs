# Date: Thu Aug 23 15:43:03 2018
# --------------
# Author: Yann Dorant
# Date:
# Modification:
# --------------
# Libraries
  #library(dplyr)
 # library(radiator)
 library(grur)
# --------------

# Set working dir -------------------------
#setwd("/media/yann/Working_disk/01_professionnel/05-Rapture_4K_indiv/")

##########################################################################################
######################             Set arguments            ##############################
##########################################################################################

args = commandArgs(trailingOnly=TRUE)

# test if there is at least one argument: if not, return an error
if (length(args) < 3) {
  message("3 arguments must be supplied")
  stop("USAGE: ./script [file.vcf] [strata.txt] [output_prefix]", call.=FALSE)
}


##########################################################################################
######################        Define global functions       ##############################
##########################################################################################

##########################################################################################
###########################        Main script       #####################################
##########################################################################################


# |---------|
# | Step 1  | ================> load data
# |---------|

vcf <- args[1]
strata <- args[2]
output <- args[3]
levels <- args[4]


grur_imputations(data = vcf,
	strata = strata,
	imputation.method = 'rf',
	hierarchical.levels = levels,
	filename = output)
#	output = c("vcf),
#	monomorphic.out = FALSE,
#	common.markers = FALSE)
